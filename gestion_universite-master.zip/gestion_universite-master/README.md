#  Gestion université

## Application réalisée avec PHP et le Framework Codeigniter v4.1.3

CodeIgniter est un framework PHP pour le developpement web full-stack qui est rapide, flexible et securisé. Pour plus d'information, rendez-vous sur le [site officiel](http://codeigniter.com).

Ce dépôt contient le [projet de gestion d'une université](https://gitlab.com/Gadnyumbaiza/gestion_universite).
Il s'agit d'un projet qui illustre comment faire le CRUD avec le framework codeigniter v4.1.3
